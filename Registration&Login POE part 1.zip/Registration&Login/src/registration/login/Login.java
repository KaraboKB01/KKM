/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registration.login;

import java.util.Scanner;
/**
 *
 * @author 27765
 */
public class Login {
    private final String Username;
    private final String Password;
   
    Scanner myscanner = new Scanner(System.in);
  //constructor 
    public Login(String username,String password){
        this.Username=username;
        this.Password=password;
     }
    //code attribute
    // this code was adapted from :"https://stackoverflow.com/questions/13674449/checking-password-code "
    // author link: "https://stackoverflow.com/users/1867612/hanyouchris"
    // author : hanyouchris
    // author : dur
    // author link :https://stackoverflow.com/users/5277820/dur 
    public boolean checkUsername(String Username){
        return Username.contains(Username)&&Username.length()<=20; 
    }
    public boolean checkpasswordComplexity(String password){

        boolean rule_1 = Password.length()>=8;
        boolean rule_2 = Password.contains("?+.*[A-Z]");
        boolean rule_3 = Password.contains("?=.*[0-9]");
        boolean rule_4 = Password.contains( "?=/\s+$ ");
       return rule_1&& rule_2 && rule_3 && rule_4;
    }
    
    public String Check(String password){
     if(!checkpasswordComplexity(password)){
         return "registered successfully.";
     } else{
         return "password doesn't meet requirements.";
     }
    }
      //check username criteria
       public  boolean  isUsernameValid (){
        boolean R1 = Username.length()<5;
        boolean R2= Username.contains("_");
        return R1 && R2;
        }
        //Output appropriate messages
    
          public static boolean isUsernameValid(String username) {
        return username.length() <= 5&& username.contains("_");
    }
         public boolean loginUser(String username,String Password){
          
          return username.equals(username)&& Password.equals(Password);
      }
          
           public String returnLoginStatus(boolean loggedIn){
          if (!loggedIn){
              return " Try again";
          } else{
              return "Successful login";
          }
      }
    
           public static String verifyLogin(String username,String Password){
               
          if(username.equals(username)&& Password.equals(Password)){
              return "Welcome"+ username;
          } else{
              return "username or password incorrect, try again.";
          }
        }
     }
      
