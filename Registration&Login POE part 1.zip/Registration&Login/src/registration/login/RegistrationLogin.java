/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registration.login;

import java.util.Scanner;

/**
 *
 * @author 27765
 */
public class RegistrationLogin {
 public String firstName;
    public String lastName;
    private String password;
    private static final String exampleUsername = "checkpasswordComplexity"; 
    private static final String examplePassword = "isUsernameValid";
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner myscanner = new Scanner(System.in);
        RegistrationLogin  account = new RegistrationLogin();
        // code atrribute
//https://stackoverflow.com/questions/25599047/java-login-program-using-a-class
//Robby Cornelissen
//https://stackoverflow.com/users/3558960/robby-cornelissen
// code adapt from Robby Cornelissen
        // Registration
        System.out.println("Enter your username");
        String username = myscanner.nextLine();
        while (!isValidUsername(username)) {
            System.out.println("Username should be at least 5 characters long and contain an underscore.");
            System.out.println("Enter your username");
            username = myscanner.nextLine();
        }
        
        System.out.println("Enter your firstName");
        account.firstName = myscanner.nextLine();

        System.out.println("Enter your lastName");
        account.lastName = myscanner.nextLine();

        System.out.println("Enter your Password");
        String password = myscanner.nextLine();
        while (!checkPasswordComplexity(password)) {
            System.out.println("Password must be at least 8 characters long and contain an underscore.");
            System.out.println("Enter your Password");
            password = myscanner.nextLine();
        }
        account.password = password;

        System.out.println("Account created successfully");
  // code attribute
        //this code was adapted from :https://codereview.stackexchange.com/questions/237623/a-simple-java-login-system
         // author: TomZ 
         //url link:https://codereview.stackexchange.com/users/218863/tomz
        // Login
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Enter your username: ");
            String enteredUsername = myscanner.nextLine();
            System.out.print("Enter your password: ");
            String enteredPassword = myscanner.nextLine();
            if (loginUser(enteredUsername, enteredPassword)) {
                // Successful login
                loggedIn = true;
                System.out.println("Welcome, " + account.firstName + " " + account.lastName + "! It's great to see you again.");
            } else {
                // Incorrect login
                System.out.println("Username or password incorrect. Please try again."); 
            }
        }
        myscanner.close();
    }
    // code attribute
// this code was taken from https://codereview.stackexchange.com/questions/237623/a-simple-java-login-system
    //url link : "https://codereview.stackexchange.com/users/109553/martin-frank
    
            //author :"Martin Frank's user avatar"

    public static boolean isValidUsername(String username) {
        return username.length() >= 5 && username.contains("_");
    }
// code attribute 
    // this code was taken from :https://codereview.stackexchange.com/questions/55841/optimizing-and-improving-a-username-regex";
    //url link :https://codereview.stackexchange.com/users/44723/mjolka
    // author : mjolka
    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 && password.contains("_");
    }

    public static boolean loginUser(String username, String password) {
        return username.equals(exampleUsername) && password.equals(examplePassword);
    }
}
    
    

