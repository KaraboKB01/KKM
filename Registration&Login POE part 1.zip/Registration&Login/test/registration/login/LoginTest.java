/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package registration.login;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 27765
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkUsername method, of class Login.
     */
    @Test
    public void testCheckUsername() {
        System.out.println("checkUsername");
        String Username = "";
        Login instance = new Login (null ,"ky1_1" );
        boolean expResult = true;
        boolean result = instance.checkUsername(Username);
        assertEquals(expResult, result);
      
    }

    /**
     * Test of checkpasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckpasswordComplexity() {
        System.out.println("checkpasswordComplexity");
        String password = "";
        Login instance = new Login(null ,"Ch&&sec@ke99!");
        boolean expResult = false;
        boolean result = instance.checkpasswordComplexity(password);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of Check method, of class Login.
     */
    @Test
    public void testCheck() {
        System.out.println("Check");
        String password = "";
        Login instance = new Login(null ,"registrated successfully");
        String expResult = "";
        String result = instance.Check(password);
        assertEquals(expResult, result);
       
    }

    /**
     * Test of isUsernameValid method, of class Login.
     */
    @Test
    public void testIsUsernameValid_0args() {
        System.out.println("isUsernameValid");
        Login instance = new Login("isUsernameValid",null);
        boolean expResult = false;
        boolean result = instance.isUsernameValid();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of isUsernameValid method, of class Login.
     */
    @Test
    public void testIsUsernameValid_String() {
        System.out.println("isUsernameValid");
       String username = "";
        boolean expResult = false;
         boolean result = Login.isUsernameValid(username);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of returnLoginStatus method, of class Login.
     */
    @Test
    public void testReturnLoginStatus() {
        System.out.println("returnLoginStatus");
        boolean loggedIn = false;
        Login instance = new Login ("LoginUser ", null);
        String expResult = "";
        String result = instance.returnLoginStatus(loggedIn);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of verifyLogin method, of class Login.
     */
    @Test
    public void testVerifyLogin() {
        System.out.println("verifyLogin");
        String username = "";
        String Password = "";
        String expResult = "";
        String result = Login.verifyLogin(username, Password);
        assertEquals(expResult, result);
       
    }
      /**
     * Test of registrationUser method, of class Login.
     */
    @Test
    public void testRegistrationUser() {
        System.out.println("registrationUser");
        String Username = "";
        String Password = "";
        String expResult = "";
        String result = Login.registrationUser(Username, Password);
        assertEquals(expResult, result);
     
    }
}
